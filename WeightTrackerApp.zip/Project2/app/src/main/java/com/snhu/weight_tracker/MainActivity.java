package com.snhu.weight_tracker;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String currentUser = getIntent().getStringExtra("currentUser");

        AuthenticatedUser user = new AuthenticatedUser();

        Button btnAddEntry = findViewById(R.id.buttonAddEntry);

        btnAddEntry.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEntryActivity.class);
            startActivity(intent);
        });

        //Load entries from db
        DBHandler db = new DBHandler(this);

        
    }


}
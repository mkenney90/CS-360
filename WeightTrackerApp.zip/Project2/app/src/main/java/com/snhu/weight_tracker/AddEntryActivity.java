package com.snhu.weight_tracker;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class AddEntryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_entry);

        Button btnCancel = findViewById(R.id.buttonCancel);
        Button btnSubmit = findViewById(R.id.buttonSubmit);

        btnCancel.setOnClickListener(l -> {
            Intent intent = new Intent(AddEntryActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}

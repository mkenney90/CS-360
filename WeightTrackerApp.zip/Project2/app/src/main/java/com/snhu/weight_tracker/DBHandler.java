package com.snhu.weight_tracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {

    private static final int VERSION = 3;
    private static final String DATABASE_NAME = "app_test.db";

    private static DBHandler instance;

    DBHandler(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        System.out.println("initiate");
    }

    private static DBHandler getInstance(Context context) {
        if (instance == null) {
            instance = new DBHandler(context);
        }

        return instance;
    }

    public static final class TableMeta {
        private static final String RECORDS_TABLE = "weight_records";
        private static final String COL_USER_ID = "user_id";
        private static final String COL_WEIGHT = "name";
        private static final String COL_DATE = "description";
        private static final String USERS_TABLE = "users";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        System.out.println("--- CREATING TABLES ---");

        String CREATE_RECORDS_TABLE_SQL =
                "CREATE TABLE IF NOT EXISTS " + TableMeta.RECORDS_TABLE + "( " +
                TableMeta.COL_USER_ID + " INTEGER," +
                TableMeta.COL_WEIGHT + " REAL," +
                TableMeta.COL_DATE + " TEXT)";

        String CREATE_USERS_TABLE_SQL =
                "CREATE TABLE IF NOT EXISTS " + TableMeta.USERS_TABLE + " (" +
                TableMeta.COL_USER_ID + " INTEGER PRIMARY KEY," +
                TableMeta.COL_USERNAME + " TEXT," +
                TableMeta.COL_PASSWORD + " TEXT)";

        System.out.println(CREATE_USERS_TABLE_SQL);

        db.execSQL(CREATE_RECORDS_TABLE_SQL);

        db.execSQL(CREATE_USERS_TABLE_SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TableMeta.RECORDS_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + TableMeta.USERS_TABLE);
        onCreate(db);
    }

    public List<WeightRecord> getWeightRecords(AuthenticatedUser user) {
        List<WeightRecord> weightRecords = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String[] projection = {TableMeta.COL_USER_ID};
        String selection = TableMeta.COL_USER_ID + " = ?";
        String[] selectArgs = {user.getUsername()};

        Cursor cursor = db.query(
            TableMeta.USERS_TABLE,
            projection,
            selection,
            selectArgs,
            null,
            null,
            null
        );

//        while (cursor.moveToNext()) {
//            System.out.println(cursor.getFloat(cursor.getColumnIndexOrThrow(TableMeta.COL_WEIGHT)));
//        }
        if (cursor.moveToNext()) {
            System.out.println("HERE");
        }
        cursor.close();
        return weightRecords;
    }

    public WeightRecord getWeightRecordById(long recordId) {
        WeightRecord weightRecord = null;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + TableMeta.RECORDS_TABLE + " WHERE " + TableMeta.COL_USER_ID + " = " + recordId;
        Cursor cursor = db.rawQuery(sql, new String[]{Long.toString(recordId)});

        if (cursor.moveToFirst()) {
            float weight = cursor.getFloat(1);
            String date = cursor.getString(2);

            weightRecord = new WeightRecord(recordId, weight, date);
        }
        cursor.close();
        return weightRecord;
    }

    public long addWeightRecord(WeightRecord weightRecord) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TableMeta.COL_WEIGHT, weightRecord.getWeight());
        values.put(TableMeta.COL_DATE, weightRecord.getDate());

        return db.insert(TableMeta.RECORDS_TABLE, null, values);
    }

    public boolean editWeightRecord(long recordId, float newWeight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TableMeta.COL_WEIGHT, newWeight);
//        values.put(WeightRecordsTable.COL_DATE, weightRecord.getDate());
        int result = db.update(
                TableMeta.RECORDS_TABLE, values, TableMeta.COL_USER_ID + " = " + recordId, null
        );

        return result == 1;
    }

    public AuthenticatedUser getUser(String username,String password){
        SQLiteDatabase db = getReadableDatabase();

        String[] projection = {
                TableMeta.COL_USER_ID,
                TableMeta.COL_USERNAME,
                TableMeta.COL_PASSWORD
        };

        String selection = TableMeta.COL_USERNAME + " = ? AND " + TableMeta.COL_PASSWORD + " = ?";
        String[] selectArgs = {username, password};

        Cursor cursor = db.query(TableMeta.USERS_TABLE, projection, selection, selectArgs, null, null, null);

        AuthenticatedUser user = new AuthenticatedUser();
        if(cursor.moveToFirst()) {
//        System.out.println(cursor.getInt(0));
            user.setUsername(cursor.getString(1));
            user.setPassword(cursor.getString(2));
        }else{
            user = null;
        }
        cursor.close();
        return user;
    }

    public boolean addUser(String username, String password){
        SQLiteDatabase db = getWritableDatabase();

        String checkIfExistsSql = "SELECT * FROM " + TableMeta.USERS_TABLE +
                " WHERE " + TableMeta.COL_USERNAME + " = ?";

        Cursor cursor = db.rawQuery(checkIfExistsSql, new String[] {username});

        System.out.println(cursor.getCount());
        if (cursor.getCount() > 0) {
            return false;
        }
        cursor.close();

        String sql = "INSERT INTO " +
                TableMeta.USERS_TABLE +
                " (" + TableMeta.COL_USER_ID + ", " + TableMeta.COL_USERNAME + ", " + TableMeta.COL_PASSWORD + " )" +
                " VALUES (NULL, ?, ?)";

        ContentValues values = new ContentValues();
        values.put(TableMeta.COL_USERNAME, username);
        values.put(TableMeta.COL_PASSWORD, password);

        long newUserId = db.insert(TableMeta.USERS_TABLE, null, values);
        System.out.println("new user ID: " + newUserId);

        return true;
    }

//    private void loadInitialData() {
//        //this is only for testing purposes
//
//        // Gets the data repository in write mode
//        SQLiteDatabase db = getWritableDatabase();
//
//        // Create a new map of values, where column names are the keys
//        ContentValues values = new ContentValues();
//        values.put(TableMeta.COL_USER_ID, 2);
//        values.put(FeedEntry.COLUMN_NAME_SUBTITLE, subtitle);
//
//        // Insert the new row, returning the primary key value of the new row
//        long newRowId = db.insert(FeedEntry.TABLE_NAME, null, values);
//    }
}

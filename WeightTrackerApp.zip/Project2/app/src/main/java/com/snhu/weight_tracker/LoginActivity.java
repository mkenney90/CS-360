package com.snhu.weight_tracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    String username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText txtFieldUsername = findViewById(R.id.editTextUsername);
        EditText txtFieldPassword = findViewById(R.id.editTextPassword);

        Button btnLogin = findViewById(R.id.buttonLogin);
        Button btnRegister = findViewById(R.id.buttonRegister);

        btnLogin.setOnClickListener(v -> {
            // get username and password from fields
             username = txtFieldUsername.getText().toString();
             password = txtFieldPassword.getText().toString();
            System.out.println(username);
            if (!username.isEmpty() && !password.isEmpty()) {
                signIn(v);
            } else {
                Toast toast = Toast.makeText(getApplicationContext(), "Please fill every field.", Toast.LENGTH_SHORT);
                toast.show();
            }
        });
        btnRegister.setOnClickListener(v -> {
            // get username and password from fields
            username = txtFieldUsername.getText().toString();
            password = txtFieldPassword.getText().toString();
            System.out.println("attempting to register " + username);
            if (!username.isEmpty() && !password.isEmpty()) {
                registerUser(v);
            } else {
                Toast toast = Toast.makeText(getApplicationContext(), "Please fill every field.", Toast.LENGTH_SHORT);
                toast.show();
            }
        });
    }

    public void signIn(View view){
        String username_in = username;
        String password_in = password;
        DBHandler db = new DBHandler(this);

        AuthenticatedUser user = db.getUser(username_in,password_in);
        if(user != null) {
            System.out.println("LOGGING IN USER ID = ");
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            intent.putExtra("currentUser", user.getUsername());
            startActivity(intent);
        } else {
            Toast toast = Toast.makeText(getApplicationContext(), "Invalid login.", Toast.LENGTH_LONG);
            toast.show();
        }
    }

    public void registerUser(View view){
        String username_in = username;
        String password_in = password;
        DBHandler db = new DBHandler(this);
        AuthenticatedUser user = new AuthenticatedUser(username_in,password_in);
        db.addUser(username, password);
        if(db.addUser(username, password)) {
            Toast toast = Toast.makeText(getApplicationContext(), "New user created!", Toast.LENGTH_LONG);
            toast.show();
        }else{
            Toast toast = Toast.makeText(getApplicationContext(), "Error creating user account.", Toast.LENGTH_LONG);
            toast.show();
        }
    }

}
